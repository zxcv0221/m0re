package com.pdsu.dao;

import java.sql.SQLException;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ArrayListHandler;

import com.pdsu.utils.JDBCUtils;
import com.pdsu.utils.JDBCUtils;

public class BookDao {
	QueryRunner qr = new QueryRunner(JDBCUtils.getDataSource());

	public void addBook(String name, String author, String sex, String price, int id, String descr) {
		try {
			qr.update("insert into book values(null,?,?,?,?,?)",author,sex,price,id,descr);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public List<Object[]> findBookByInfo(String text) {
		List<Object[]> list = null;
		try {
			list = qr.query("select b.id,b.name,b.author,b.sex,b.price,t.type,b.descr,t.id from book b left join bookType t on b.tid = t.id"
					+ " where name like '%' ? '%'", new ArrayListHandler(),text);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public void deleteBookById(String id) {
		try {
			qr.update("delete from book where id = ?",id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void updateBook(String id, String bookName, String author, String sex, String price, int tid, String descr) {
		try {
			qr.update("update book set name = ?,author = ?,sex = ?,price = ?,tid = ?, descr = ? where id = ?",bookName,author,sex,price,tid,descr,id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
