package com.pdsu.dao;

import java.sql.SQLException;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ArrayListHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.pdsu.utils.JDBCUtils;
import com.pdsu.model.BookType;
import com.pdsu.utils.JDBCUtils;

public class BookTypeDao {

	QueryRunner qr = new QueryRunner(JDBCUtils.getDataSource());

	public void addType(String text, String text2) {
		try {
			qr.update("insert into bookType values (null,?,?)",text,text2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public 	List<Object[]> findBookTypeByInfo(String text) {
		List<Object[]> list = null;
		try {
			list = qr.query("select * from bookType where type like '%' ? '%'", new ArrayListHandler(),text);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}

	public void updateType(String text, String text2, String text3) {
		try {
			qr.update("update bookType set type = ?, descr = ? where id = ?",text2,text3,text);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void deleteTypeById(String id) {
		try {
			qr.update("delete from bookType where id = ?",id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}
