package com.pdsu.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.pdsu.model.User;
import com.pdsu.utils.JDBCUtils;

public class UserDao {

	private QueryRunner qr = new QueryRunner(JDBCUtils.getDataSource());
	public void addUser(String name, String pwd) {
		
		try {
			qr.update("insert into user values (null,?,?)",name,pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public User chekUser(String name, String pwd) {
		User u = null;
		try {
			u = qr.query("select * from user where name = ? and pwd = ?", new BeanHandler<>(User.class),name,pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return u;
	}

	
}
