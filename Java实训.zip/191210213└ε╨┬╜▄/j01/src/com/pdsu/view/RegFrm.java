package com.pdsu.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.pdsu.dao.UserDao;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RegFrm extends JFrame {

	private JPanel contentPane;
	private JTextField nameText;
	private JPasswordField pwdText;
	private JPasswordField rpwdText;
	private UserDao ud = new UserDao();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegFrm frame = new RegFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegFrm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel label = new JLabel("�û���");
		
		JLabel label_1 = new JLabel("����");
		
		JLabel label_2 = new JLabel("ȷ������");
		
		nameText = new JTextField();
		nameText.setColumns(10);
		
		pwdText = new JPasswordField();
		
		rpwdText = new JPasswordField();
		
		JButton button = new JButton("����");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reset();
			}
		});
		
		JButton button_1 = new JButton("ע��");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reg();
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(36)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(label)
						.addComponent(label_2)
						.addComponent(label_1))
					.addGap(41)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(rpwdText)
						.addComponent(pwdText)
						.addComponent(nameText, GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE))
					.addContainerGap(109, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(47)
					.addComponent(button)
					.addPreferredGap(ComponentPlacement.RELATED, 192, Short.MAX_VALUE)
					.addComponent(button_1)
					.addGap(71))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(nameText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(pwdText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(label_1))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(rpwdText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(label_2)))
						.addComponent(label))
					.addPreferredGap(ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(button)
						.addComponent(button_1))
					.addGap(28))
		);
		contentPane.setLayout(gl_contentPane);
		setLocationRelativeTo(null);
	}

	private void reg() {
		String name = nameText.getText();
		String pwd = new String(pwdText.getPassword());
		String rpwd = new String(rpwdText.getPassword());
		if(name.equals("")||pwd.equals("")||rpwd.equals("")){
			JOptionPane.showMessageDialog(null, "���벻��Ϊ��");
			return;
		}
		if(!pwd.equals(rpwd)){
			JOptionPane.showMessageDialog(null, "�������벻һ��������������");
			pwdText.setText("");
			rpwdText.setText("");
			return;
		}
		ud.addUser(name,pwd);
		
		dispose();
		new LoginFrm().setVisible(true);
		
		
	}

	private void reset() {
		nameText.setText("");
		pwdText.setText("");
		rpwdText.setText("");
		
	}

}
