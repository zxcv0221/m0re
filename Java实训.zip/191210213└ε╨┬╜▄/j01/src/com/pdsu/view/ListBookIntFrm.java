package com.pdsu.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.pdsu.dao.BookDao;
import com.pdsu.dao.BookTypeDao;
import com.pdsu.model.BookType;

import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ListBookIntFrm extends JInternalFrame {
	private JTextField nameText;
	private JTable table;
	private BookDao bd = new BookDao();
	private BookTypeDao btd = new BookTypeDao();
	private JTextField idText;
	private JTextField bookNameText;
	private JTextField authorText;
	private JTextField priceText;
	private JRadioButton manRadio;
	private JRadioButton womanRadio;
	private JComboBox typeBox;
	private JTextArea descrText;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListBookIntFrm frame = new ListBookIntFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListBookIntFrm() {
		setTitle("ͼ�����ݹ���");
		setIconifiable(true);
		setClosable(true);
		setBounds(100, 100, 722, 501);
		
		JLabel label = new JLabel("ͼ������");
		
		nameText = new JTextField();
		nameText.setColumns(10);
		
		JButton button = new JButton("��ѯ");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				findBookByInfo();
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u56FE\u4E66\u8868\u5355", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap(187, Short.MAX_VALUE)
					.addComponent(label)
					.addGap(18)
					.addComponent(nameText, GroupLayout.PREFERRED_SIZE, 277, GroupLayout.PREFERRED_SIZE)
					.addGap(36)
					.addComponent(button)
					.addGap(83))
				.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap()
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 603, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addGap(74)
							.addComponent(panel, GroupLayout.PREFERRED_SIZE, 609, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(23, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(59)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(button)
						.addComponent(nameText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label))
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 129, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		JLabel label_1 = new JLabel("ͼ����");
		
		idText = new JTextField();
		idText.setEnabled(false);
		idText.setEditable(false);
		idText.setColumns(10);
		
		JLabel label_2 = new JLabel("ͼ������");
		
		bookNameText = new JTextField();
		bookNameText.setColumns(10);
		
		JLabel label_3 = new JLabel("��������");
		
		authorText = new JTextField();
		authorText.setColumns(10);
		
		JLabel label_4 = new JLabel("ͼ��۸�");
		
		priceText = new JTextField();
		priceText.setColumns(10);
		
		JLabel label_5 = new JLabel("ͼ�����");
		
		 typeBox = new JComboBox();
		
		JLabel label_6 = new JLabel("ͼ������");
		
		 descrText = new JTextArea();
		
		JButton button_1 = new JButton("ɾ��");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteBook();
			}
		});
		
		JButton button_2 = new JButton("�޸�");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateBook();
			}
		});
		
		JLabel label_7 = new JLabel("�����Ա�");
		
		manRadio = new JRadioButton("��");
		manRadio.setSelected(true);
		buttonGroup.add(manRadio);
		
		womanRadio = new JRadioButton("Ů");
		buttonGroup.add(womanRadio);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(label_6)
					.addGap(18)
					.addComponent(descrText, GroupLayout.PREFERRED_SIZE, 462, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(14, Short.MAX_VALUE))
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_1)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(idText, GroupLayout.PREFERRED_SIZE, 101, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_7)
							.addGap(18)
							.addComponent(manRadio)
							.addGap(18)
							.addComponent(womanRadio)))
					.addGap(28)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_4)
							.addGap(18)
							.addComponent(priceText))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_2)
							.addGap(18)
							.addComponent(bookNameText, GroupLayout.PREFERRED_SIZE, 135, GroupLayout.PREFERRED_SIZE)))
					.addGap(34)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_3)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(authorText, GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE))
						.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
							.addComponent(label_5)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(typeBox, 0, 103, Short.MAX_VALUE)))
					.addContainerGap())
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(53)
					.addComponent(button_1)
					.addPreferredGap(ComponentPlacement.RELATED, 340, Short.MAX_VALUE)
					.addComponent(button_2)
					.addGap(45))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_1)
						.addComponent(idText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_3)
						.addComponent(authorText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_2)
						.addComponent(bookNameText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(32)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_7)
						.addComponent(manRadio)
						.addComponent(womanRadio)
						.addComponent(label_4)
						.addComponent(priceText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(typeBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_5))
					.addGap(15)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(label_6)
						.addComponent(descrText, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(button_2)
						.addComponent(button_1))
					.addGap(38))
		);
		panel.setLayout(gl_panel);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				selectRow();
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u7F16\u53F7", "\u56FE\u4E66\u540D\u79F0", "\u56FE\u4E66\u4F5C\u8005", "\u4F5C\u8005\u6027\u522B", "\u56FE\u4E66\u4EF7\u683C", "\u56FE\u4E66\u7C7B\u578B", "\u56FE\u4E66\u63CF\u8FF0"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
		getContentPane().setLayout(groupLayout);
		loadType();
		findBookByInfo();
		
	}
	
	protected void updateBook() {
		String id = idText.getText();
		String bookName = bookNameText.getText();
		String author = authorText.getText();
		String sex = manRadio.isSelected()?"��":"Ů";
		String price = priceText.getText();
		BookType bt  = (BookType) typeBox.getSelectedItem();
		String descr = descrText.getText();
		bd.updateBook(id,bookName,author,sex,price,bt.getId(),descr);
		findBookByInfo();
		
	}

	protected void deleteBook() {
		int row = table.getSelectedRow();
		if(row >= 0 ){
			bd.deleteBookById(table.getValueAt(row, 0)+"");
			findBookByInfo();
		}
	}

	private void loadType(){
		List<Object[]> list = btd.findBookTypeByInfo("");
		for (Object[] objs : list) {
			BookType bt = new BookType();
			bt.setId((Integer)objs[0]);
			bt.setType((String)objs[1]);
			typeBox.addItem(bt);
		}
	}
	
	private void selectRow() {
		int row = table.getSelectedRow();
		if(row >= 0 ){
			idText.setText(table.getValueAt(row, 0)+"");
			bookNameText.setText((String)table.getValueAt(row, 1));
			authorText.setText((String)table.getValueAt(row, 2));
			manRadio.setSelected(((String)table.getValueAt(row, 3)).equals("��"));
			priceText.setText(table.getValueAt(row, 4)+"");
			String bookType = (String)table.getValueAt(row, 5);
			int num = typeBox.getItemCount();
			for(int i = 0; i < num; i++){
				BookType bt  = (BookType) typeBox.getItemAt(i);
				if(bt.getType().equals(bookType)){
					typeBox.setSelectedIndex(i);
					break;
				}
			}
			descrText.setText((String)table.getValueAt(row, 6));
		}else{
			idText.setText("");
			bookNameText.setText("");
			authorText.setText("");
			manRadio.setSelected(true);
			priceText.setText("");
			typeBox.setSelectedIndex(0);
			descrText.setText("");
		}
	}

	private void findBookByInfo() {
		DefaultTableModel model =  (DefaultTableModel)table.getModel();
		model.setRowCount(0);
	    List<Object[]> list = bd.findBookByInfo(nameText.getText());
	    for (Object[] objects : list) {
		  model.addRow(objects);
	    }
	    selectRow();
	}
}
