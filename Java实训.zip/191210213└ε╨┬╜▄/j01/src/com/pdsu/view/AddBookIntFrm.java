package com.pdsu.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;

import com.pdsu.dao.BookDao;
import com.pdsu.dao.BookTypeDao;
import com.pdsu.model.BookType;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;

public class AddBookIntFrm extends JInternalFrame {
	private JTextField nameText;
	private JTextField author;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField priceText;
	private BookTypeDao btd = new BookTypeDao();
	private BookDao bd = new BookDao();
	private JComboBox typeBox;
	private JRadioButton manRadio;
	private JRadioButton womanRadio;
	private JTextArea descrText;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddBookIntFrm frame = new AddBookIntFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddBookIntFrm() {
		setTitle("����ͼ��");
		setIconifiable(true);
		setClosable(true);
		setBounds(100, 100, 698, 521);
		
		JLabel label = new JLabel("ͼ������:");
		
		nameText = new JTextField();
		nameText.setColumns(10);
		
		JLabel label_1 = new JLabel("��������:");
		
		author = new JTextField();
		author.setColumns(10);
		
		JLabel label_2 = new JLabel("�����Ա�:");
		
		 manRadio = new JRadioButton("��");
		buttonGroup.add(manRadio);
		manRadio.setSelected(true);
		
		 womanRadio = new JRadioButton("Ů");
		buttonGroup.add(womanRadio);
		
		JLabel lblNewLabel = new JLabel("ͼ��۸�");
		
		priceText = new JTextField();
		priceText.setColumns(10);
		
		JLabel label_3 = new JLabel("ͼ�����");
		
		JLabel label_4 = new JLabel("ͼ��������");
		
		 descrText = new JTextArea();
		
		typeBox = new JComboBox();
		
		JButton button = new JButton("����");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reset();
			}
		});
		
		JButton button_1 = new JButton("����");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				add();
			}
		});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(39)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(label_4)
							.addGap(37)
							.addComponent(descrText, GroupLayout.PREFERRED_SIZE, 382, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(label_3)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(typeBox, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(label)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(nameText, GroupLayout.PREFERRED_SIZE, 177, GroupLayout.PREFERRED_SIZE))
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(label_2)
									.addGap(18)
									.addComponent(manRadio)
									.addGap(18)
									.addComponent(womanRadio)))
							.addGap(130)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(label_1)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(author, GroupLayout.PREFERRED_SIZE, 169, GroupLayout.PREFERRED_SIZE))
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(lblNewLabel)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(priceText)))))
					.addContainerGap(51, Short.MAX_VALUE))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(117)
					.addComponent(button)
					.addPreferredGap(ComponentPlacement.RELATED, 257, Short.MAX_VALUE)
					.addComponent(button_1)
					.addGap(194))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(42)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(nameText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_1)
						.addComponent(author, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(45)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(manRadio)
						.addComponent(womanRadio)
						.addComponent(lblNewLabel)
						.addComponent(priceText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(label_3)
								.addComponent(typeBox, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
							.addGap(75)
							.addComponent(label_4)
							.addGap(155))
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
							.addComponent(descrText, GroupLayout.PREFERRED_SIZE, 189, GroupLayout.PREFERRED_SIZE)
							.addGap(18)))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(button)
						.addComponent(button_1))
					.addGap(15))
		);
		getContentPane().setLayout(groupLayout);
		loadType();
	}

	private void loadType(){
		List<Object[]> list = btd.findBookTypeByInfo("");
		for (Object[] objs : list) {
			BookType bt = new BookType();
			bt.setId((Integer)objs[0]);
			bt.setType((String)objs[1]);
			typeBox.addItem(bt);
		}
	}
	
	private void add() {
		bd.addBook(nameText.getText(),
				author.getText(),
				manRadio.isSelected()?"��":"Ů",
				priceText.getText(),
				((BookType)typeBox.getSelectedItem()).getId(),
				descrText.getText());
		JOptionPane.showMessageDialog(null, "���ӳɹ�");
		reset();
	}

	private void reset() {
		nameText.setText("");
		author.setText("");
		manRadio.setSelected(true);
		priceText.setText("");
		typeBox.setSelectedIndex(0);
		descrText.setText("");
	}
}
