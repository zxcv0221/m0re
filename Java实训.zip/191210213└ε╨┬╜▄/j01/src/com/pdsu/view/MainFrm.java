package com.pdsu.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JDesktopPane;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainFrm extends JFrame {

	private JPanel contentPane;
	private JDesktopPane desktopPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrm frame = new MainFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 715, 503);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu = new JMenu("ͼ�����");
		menuBar.add(menu);
		
		JMenu menu_2 = new JMenu("ͼ��������");
		menu.add(menu_2);
		
		JMenuItem menuItem = new JMenuItem("�������");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddBookTypeIntFrm addBookTypeIntFrm = new AddBookTypeIntFrm();
				addBookTypeIntFrm.setVisible(true);
				desktopPane.add(addBookTypeIntFrm);
			}
		});
		menu_2.add(menuItem);
		
		JMenuItem menuItem_1 = new JMenuItem("ͼ�����ά��");
		menuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ListBookTypeIntFrm lbtif = new ListBookTypeIntFrm();
				lbtif.setVisible(true);
				desktopPane.add(lbtif);
			}
		});
		menu_2.add(menuItem_1);
		
		JMenu menu_3 = new JMenu("ͼ�����");
		menu.add(menu_3);
		
		JMenuItem menuItem_2 = new JMenuItem("����ͼ��");
		menuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddBookIntFrm abif = new AddBookIntFrm();
				abif.setVisible(true);
				desktopPane.add(abif);
			}
		});
		menu_3.add(menuItem_2);
		
		JMenuItem menuItem_3 = new JMenuItem("ά��ͼ��");
		menuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ListBookIntFrm lbif = new ListBookIntFrm();
				lbif.setVisible(true);
				desktopPane.add(lbif);
			}
		});
		menu_3.add(menuItem_3);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		 desktopPane = new JDesktopPane();
		desktopPane.setBackground(Color.RED);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addComponent(desktopPane, GroupLayout.DEFAULT_SIZE, 689, Short.MAX_VALUE)
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addComponent(desktopPane, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 434, Short.MAX_VALUE)
		);
		GroupLayout gl_desktopPane = new GroupLayout(desktopPane);
		gl_desktopPane.setHorizontalGroup(
			gl_desktopPane.createParallelGroup(Alignment.LEADING)
				.addGap(0, 435, Short.MAX_VALUE)
		);
		gl_desktopPane.setVerticalGroup(
			gl_desktopPane.createParallelGroup(Alignment.LEADING)
				.addGap(0, 231, Short.MAX_VALUE)
		);
		desktopPane.setLayout(gl_desktopPane);
		contentPane.setLayout(gl_contentPane);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
	}
}
